﻿namespace MotoTest
{
    [TestClass]
    public class MoteurTest
    {
        int taille;
        int nbCylindres;
        int puissanceChevauxVapeur;
        double consomationParKm;

        Moteur moteurDeTest;

        private const string Expected = "Vrooooom !";

        [TestInitialize]
        public void Init()
        {
            taille = 1;
            nbCylindres = 2;
            puissanceChevauxVapeur = 3;
            consomationParKm = 5;

            moteurDeTest = new Moteur(taille, nbCylindres, puissanceChevauxVapeur, consomationParKm);
        }

        //VERIFICATION DU CONSTRUCTEUR
        [TestMethod]
        public void Moteur_initCorrect_returnTaille()
        {
            Assert.AreEqual(taille, moteurDeTest.Taille);
        }

        [TestMethod]
        public void Moteur_initCorrect_returnNbCylindres()
        {
            Assert.AreEqual(nbCylindres, moteurDeTest.NbCylindres);
        }

        [TestMethod]
        public void Moteur_initCorrect_returnPuissanceChevauxVapeur()
        {
            Assert.AreEqual(puissanceChevauxVapeur, moteurDeTest.PuissanceChevauxVapeur);
        }

        [TestMethod]
        public void Moteur_initCorrect_returnConsomationParKm()
        {
            Assert.AreEqual(consomationParKm, moteurDeTest.ConsommationParKm);
        }

        //VERIFICATION METHODE
        [TestMethod]
        public void Moteur_methodeCorrect_DemarrerMoteur()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                moteurDeTest.DemarrerMoteur();

                var result = sw.ToString().Trim();
                Assert.AreEqual(Expected, result);
            }
        }
    }
}
