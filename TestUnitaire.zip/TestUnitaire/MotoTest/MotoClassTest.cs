﻿namespace MotoTest
{
    [TestClass]
    public class MotoClassTest
    {
        private Moteur moteur;
        private Roue roue;
        Roue[] roues;
        private string style;
        private int tailleReservoir;
        private double distanceParcourue;

        private int dureeVieKm;
        private int autonomieKm;
        private string couleur;
        private int anneeDeProduction;
        private string marque;
        private string modele;

        Moto motoTest;

        [TestInitialize]
        public void Init()
        {
            moteur = new Moteur(100, 6, 200, 1);
            roue = new Roue(1, 100, 10, 20, 'A', 30, "Vans");
            roues = new Roue[]{ new Roue(roue), new Roue(roue) };
            style = "Chopper";
            tailleReservoir = 30;
            distanceParcourue = 0;

            dureeVieKm = 100;
            autonomieKm = 10;
            couleur = "Red";
            anneeDeProduction = 2020;
            marque = "Harley Davidson";
            modele = "Street Bob";

            motoTest = new Moto(dureeVieKm, style, tailleReservoir, moteur, roue, couleur, marque, modele);
        }

        [TestMethod]
        public void Moto_initCorrect_returnStyle()
        {
            Assert.AreEqual(style, motoTest.Style);
        }

        [TestMethod]
        public void Moto_initCorrect_Roues()
        {
            Assert.AreEqual(roues, motoTest.Roues);
        }

        [TestMethod]
        public void Moto_initCorrect_DistanceParcourue()
        {
            Assert.AreEqual(distanceParcourue, motoTest.DistanceParcourue);
        }

        //TEST METHODE
        [TestMethod]
        public void Moto_methodeCorrect_Demarrer()
        {
            motoTest.Demarrer();
            Assert.AreEqual(ConsoleColor.Red, Console.ForegroundColor);
        }

        [TestMethod]
        public void Moto_methodeCorrect_Rouler()
        {
            motoTest.Rouler(150);
            Assert.IsTrue(motoTest.DistanceParcourue >= dureeVieKm);
        }
    }
}
