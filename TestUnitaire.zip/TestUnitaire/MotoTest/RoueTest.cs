﻿namespace MotoTest
{
    [TestClass]
    public class RoueTest
    {
        int largeur;
        int pourcentageHauteur;
        int diametreJante;
        int indiceCharge;
        char indiceVitesse;
        int pression;
        string type;

        Roue roueDeTest1;
        Roue roueDeTest2;

        [TestInitialize]
        public void Init()
        {
            largeur = 1;
            pourcentageHauteur = 100;
            diametreJante = 10;
            indiceCharge = 20;
            indiceVitesse = 'A';
            pression = 30;
            type = "Vans";

            roueDeTest1 = new Roue(largeur, pourcentageHauteur, diametreJante, indiceCharge, indiceVitesse, pression, type);
            roueDeTest2 = new Roue(roueDeTest1);
        }

        //VERIFICATION DU CONSTRUCTEUR
        [TestMethod]
        public void Roue_initCorrect_returnLargeur()
        {
            Assert.AreEqual(largeur, roueDeTest1.Largeur);
        }

        [TestMethod]
        public void Roue_initCorrect_returnPourcentageHauteur()
        {
            Assert.AreEqual(pourcentageHauteur, roueDeTest1.PourcentageHauteur);
        }

        [TestMethod]
        public void Roue_initCorrect_returnDiametreJante()
        {
            Assert.AreEqual(diametreJante, roueDeTest1.DiametreJante);
        }

        [TestMethod]
        public void Roue_initCorrect_returnIndiceCharge()
        {
            Assert.AreEqual(indiceCharge, roueDeTest1.IndiceCharge);
        }

        [TestMethod]
        public void Roue_initCorrect_returnIndiceVitesse()
        {
            Assert.AreEqual(indiceVitesse, roueDeTest1.IndiceVitesse);
        }

        [TestMethod]
        public void Roue_initCorrect_returnPression()
        {
            Assert.AreEqual(pression, roueDeTest1.Pression);
        }

        [TestMethod]
        public void Roue_initCorrect_returnType()
        {
            Assert.AreEqual(type, roueDeTest1.Type);
        }

        //VERIFICATION CONSTRUCTEUR PAR COPIE
        [TestMethod]
        public void Roue_initCorrect_returnCloneLargeur()
        {
            Assert.AreEqual(largeur, roueDeTest2.Largeur);
        }

        [TestMethod]
        public void Roue_initCorrect_returnClonePourcentageHauteur()
        {
            Assert.AreEqual(pourcentageHauteur, roueDeTest2.PourcentageHauteur);
        }

        [TestMethod]
        public void Roue_initCorrect_returnCloneDiametreJante()
        {
            Assert.AreEqual(diametreJante, roueDeTest2.DiametreJante);
        }

        [TestMethod]
        public void Roue_initCorrect_returnCloneIndiceCharge()
        {
            Assert.AreEqual(indiceCharge, roueDeTest2.IndiceCharge);
        }

        [TestMethod]
        public void Roue_initCorrect_returnCloneIndiceVitesse()
        {
            Assert.AreEqual(indiceVitesse, roueDeTest2.IndiceVitesse);
        }

        [TestMethod]
        public void Roue_initCorrect_returnClonePression()
        {
            Assert.AreEqual(pression, roueDeTest2.Pression);
        }

        [TestMethod]
        public void Roue_initCorrect_returnCloneType()
        {
            Assert.AreEqual(type, roueDeTest2.Type);
        }

        //VERIFICATION METHODE
        [TestMethod]
        public void Roue_methodeCorrect_GonflerPneu()
        {
            
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                roueDeTest1.GonflerPneu(1);

                var result = sw.ToString().Trim();
                Assert.AreEqual("Vous avez gonflé le pneu.", result);
            }
            Assert.AreEqual(pression+1, roueDeTest1.Pression);
        }
    }
}