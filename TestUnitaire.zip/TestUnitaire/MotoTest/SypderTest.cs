﻿namespace MotoTest
{
    [TestClass]
    public class SypderTest
    {
        private Moteur moteur;
        private Roue roue;
        Roue[] roues;
        private string style;
        private int tailleReservoir;
        private double distanceParcourue;

        private int dureeVieKm;
        private int autonomieKm;
        private string couleur;
        private int anneeDeProduction;
        private string marque;
        private string modele;

        Spyder spyderTest;

        [TestInitialize]
        public void Init()
        {
            moteur = new Moteur(100, 6, 200, 1);
            roue = new Roue(1, 100, 10, 20, 'A', 30, "Vans");
            roues = new Roue[] { new Roue(roue), new Roue(roue), new Roue(roue) };
            tailleReservoir = 30;
            distanceParcourue = 0;

            dureeVieKm = 100;
            autonomieKm = 10;
            couleur = "Yellow";
            anneeDeProduction = 2020;
            marque = "Can-Am";
            modele = "F3 SE6";

            spyderTest = new Spyder(dureeVieKm, tailleReservoir, moteur, roue, couleur, marque, modele);
        }

        [TestMethod]
        public void Spyder_methodeCorrect_tournerSerrer()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                spyderTest.TournerSerrer();

                var result = sw.ToString().Trim();
                Assert.AreEqual("Pour faire le tournant serré, vous avez simplement tourné la direction de la Spyder.", result);
            }
        }

    }
}
