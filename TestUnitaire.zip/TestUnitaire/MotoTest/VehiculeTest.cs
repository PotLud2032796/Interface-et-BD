﻿namespace MotoTest
{
    [TestClass]
    public class VehiculeTest       //NOTHING FOR NOW
    {
        private int dureeVieKm;
        private int autonomieKm;
        private string couleur;
        private int anneeDeProduction;
        private string marque;
        private string modele;
    }
}
